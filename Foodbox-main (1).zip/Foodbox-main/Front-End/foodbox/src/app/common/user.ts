export class User {
    id: number;
    username: string;
    password: string;
    email: string;
    type: number;
    phone: number;
    zipcode: string;
    street: string;
    city: string;

}
